<template>
    <masterChart :chartJenisKelamin="chartJenisKelamin" :chartOptionsJenisKelamin="chartOptionsJenisKelamin" />

    <div class="justify-content-center custom-chart " ref="chartContainer">
        <Chart v-if="chartStatusPegawai" type="pie" :data="chartStatusPegawai" :options="chartOptionsStatusPegawai"
            :plugins="plugins" />
    </div>
</template>

<script>
import masterChart from '../components/masterChart.vue';

export default {
    components: {
        masterChart,
    },
    data() {
        return {
            chartJenisKelamin: null,
            chartOptionsJenisKelamin: null
        }
    },
    // Lakukan penyesuaian lain yang diperlukan
}
</script>
