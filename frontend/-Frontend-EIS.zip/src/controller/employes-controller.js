// import employesService from "../service/employes-service";
import {
  // api,
  hrisServiceHr1Mod1,
  hrisServiceHr2Mod3,
  hrisServiceAuthInfo,
  token,
} from "../api/index";

import DataTable from "primevue/datatable";
import Column from "primevue/column";

export default {
  components: {
    DataTable,
    Column,
  },
  data() {
    return {
      currentDate: '',
      
      //dialog opener
      visible1: false, //dialog opener
      visible2: false,
      clickJenisKelamin: false,
      clickStatus: false,
      clickDepartemen: false,
      clickJabatan: false,
      clickUsiaDanJenisKelamin: false,
      clickMasaKerja: false,

      filterNama: "",
      responseData: [],
      responseDataHris: [],
      responseDataJenisKelamin: [],
      responseDataJabatanTotal: [],
      responseDataDepartemenTotal: [],
      responseDataPendidikanTerakhir: [],
      responseDataRekapByRuanganHarian: [],
      responseDataFilterLokasiKerja: [],
      responseDataFilterStatusPegawai: [],
      responseDataFotoDiri: [],
      responseDataUsiaDanJenisKelamin: [],
      responseDataPegawaiMasaKerja:[],

      responDataPegawaiStrSip: [],
      items: [
        {
          label: "Dashboard",
          icon: "pi pi-home",
           command: () => {
            this.$router.push('/eis');
        }
        },
        {
          label: "Demografi",
          icon: "pi pi-star",
          command: () => {
            this.$router.push('/demografi');
        }
        },
        {
          label: "Kehadiran",
          icon: "pi pi-calendar",
           command: () => {
            this.$router.push('/kehadiran');
        }
        },
        {
          label: "Payroll",
          icon: "pi pi-dollar",
          badge: 3,
        },
      ],

       selectedCity: null,
            cities: [
                { name: 'New York', code: 'NY' },
                { name: 'Rome', code: 'RM' },
                { name: 'London', code: 'LDN' },
                { name: 'Istanbul', code: 'IST' },
                { name: 'Paris', code: 'PRS' }
            ],

      // RENDER CHART++++++++++++

      customer: null,
    };
  },

  mounted() {
    // this.fetchData();
    // this.search();
    // this.hitungTotalPegawai;
    this.fetchDataHris();
    this.filterJenisKelamin();
    this.rekapByRuanganHarian();
    this.filterJabatanTotal();
    this.filterDepartemenTotal();
    this.pendidikanTerakhir();
    this.filterLokasiKerja();
    this.filterStatusPegawai();
    this.tampilFotoDiri();
    this.usiaDanJenisKelamin();

    this.pegawaiStrStip();
    this.getCurrentDate();
    this.pegawaiMasaKerja();
  },
  methods: {

    getCurrentDate() {
      const today = new Date();
      const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      this.currentDate = today.toLocaleDateString('id-ID', options);
    },
  
    // ...employesService,
    //keterangan kehadiran pegawai total
    async fetchDataHris() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterAbsensi",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataHris = response.data.data.jumlahPegawaiFilter;
        // console.log(this.responseDataHris);
      } catch (error) {
        console.error("error fetching Service", error);
      }
    },

    //Absensi Harian
    async rekapByRuanganHarian() {
      try {
        const response = await hrisServiceHr2Mod3.get(
          "rekapitulasiAbsensiV2/findRekapByRuanganHarian",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );

        // Memperbarui responseDataRekapByRuanganHarian dengan menambahkan URL foto
        this.responseDataRekapByRuanganHarian =
          response.data.data.rekapAbsen.map((item) => {
            // Membuat URL foto berdasarkan data pada item
            const photoUrl = item.imagePegawaiIn
              ? `http://bdg2.jasamedika.com:2304/authInfo/image/showPhotos/${item.imagePegawaiIn}`
              : `http://bdg2.jasamedika.com:2304/authInfo/image/show/${item.photoDiri}`;
            // Mengembalikan objek baru yang sudah diperbarui dengan URL foto
            return {
              ...item,
              photoUrl: photoUrl,
            };
          });

        console.log(this.responseDataRekapByRuanganHarian);
      } catch (error) {
        console.error("error fetching service", error);
      }
    },

    //menampilkan foto absensi
    async tampilFotoDiri() {
      try {
        const response = await hrisServiceAuthInfo.get("image/showPhotos", {
          headers: {
            "x-auth-token": `${token}`,
          },
        });
        this.responseDataFotoDiri = response;
        console.log(this.responseDataFotoDiri);
      } catch (error) {
        console.error("error fetching service", error);
      }
    },

    async filterJenisKelamin() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterJenisKelamin",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataJenisKelamin = response.data.data.jumlahPegawaiFilter;
        // console.log(this.responseDataJenisKelamin);
      } catch (error) {
        console.error("error fetching Service", error);
      }
    },

    async usiaDanJenisKelamin() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterUsiadanJK",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataUsiaDanJenisKelamin = response.data.data.data;
        // console.log(this.responseDataUsiaDanJenisKelamin);
      } catch (error) {
        console.error("error fetching Service", error);
      }
    },

    async filterJabatanTotal() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahJabatan",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataJabatanTotal = response.data.data.jabatanTotal;
        // console.log(this.responseDataJabatanTotal);
      } catch (error) {
        console.error("Error Fetching Data Jabatan Departemen", error);
      }
    },

    async filterDepartemenTotal() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterDepartemen",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataDepartemenTotal = response.data.data.listPegawai;
        // console.log(this.responseDataDepartemenTotal);
      } catch (error) {
        console.error("Error Fetching Data Jabatan Departemen", error);
      }
    },

    async pendidikanTerakhir() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterPendidikan",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataPendidikanTerakhir =
          response.data.data.jumlahPegawaiFilter;
        // console.log(this.responseDataPendidikanTerakhir);
      } catch (error) {
        console.error("Error Fetching Data Pendidikan Terakhir", error);
      }
    },

    async filterLokasiKerja() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterLokasiKerja",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataFilterLokasiKerja =
          response.data.data.jumlahPegawaiFilter;
        // console.log(this.responseDataFilterLokasiKerja);
      } catch (error) {
        console.error("Error Fething Data Lokasi Kerja", error);
      }
    },

    async filterStatusPegawai() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterKategory",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataFilterStatusPegawai =
          response.data.data.jumlahPegawaiFilter;
        // console.log(this.responseDataFilterStatusPegawai);
      } catch (error) {
        console.error("Error Fetching Data Status Pegawai", error);
      }
    },

    async pegawaiStrStip() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "dokumen/findAll?page=1&rows=10&dir=namaJudulDokumen&sort=desc&namaDokumen=STR",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responDataPegawaiStrSip = response.data.Dokumen;
        console.log(this.responDataPegawaiStrSip);
      } catch (error) {
        console.error("Error Fetching STR SIP", error);
      }
    },

    async pegawaiMasaKerja() {
      try {
        const response = await hrisServiceHr1Mod1.get(
          "registrasiPegawai/findJumlahPegawaiFilterMasaKerja",
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
    );
    this.responseDataPegawaiMasaKerja = response.data.data.data;
    console.log(this.responseDataPegawaiMasaKerja);
        
      } catch (error) {
        console.error("Error fething Masa Kerja", error);
      }
    },

    // async fetchData() {
    //   try {
    //     const response = await api.get("api/employes");
    //     this.responseData = response.data;
    //     // console.log(this.responseData);

    //     //hitung total data
    //     this.totalData = this.responseData.length;

    //     //panggil metode chart untuk mengatur data chart
    //     // this.setChartPGender();
    //     // this.setChartPStatus();
    //     // this.setChartPLokasi();
    //   } catch (error) {
    //     console.error("Error fetching data:", error);
    //   }
    // },
    //========================= CHART =========================

    // async search(keyword) {
    //   try {
    //     if (this.filterNama) {
    //       const response = await api.get(`api/employes/search?nama=${keyword}`);
    //       this.responseData = response.data;
    //     } else {
    //       this.fetchData();
    //     }
    //   } catch (error) {
    //     // handle error
    //     console.error("Error during search", error);
    //   }
    // },
    buttonSearchNama() {
      this.search(this.filterNama);
    },

    exportCSV() {
      this.$refs.dt.exportCSV();
    },
  },
};
