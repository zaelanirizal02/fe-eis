//import vue router
import { createRouter, createWebHistory } from "vue-router";
// import AppLayout from "../views/layout/AppLayout.vue";

//define a routes
const routes = [

  // {
  //   path: "/",
  //   component: AppLayout,
  //   children: [
  //     {
  //       path: "/",
  //       name: "employes",
  //       component: () => import("../views/employes/index.vue"),
  //     },
  //   ],
  // },
  {
    path: "/",
    name: "auth.login",
    component: () => import("../views/auth/login-page.vue"),
  },
  {
    path: "/eis",
    name: "employes.index",
    component: () => import("../views/employes/index.vue"),
  },
  {
    path: "/demografi",
    name: "employes.demografi",
    component: () => import("../views/employes/demografi.vue"),
  },
   {
    path: "/kehadiran",
    name: "employes.kehadiran",
    component: () => import("../views/employes/kehadiran.vue"),
  },
  // {
  //   path: "/apex",
  //   name: "employes.apex",
  //   component: () => import("../views/employes/apex.vue"),
  // },
];

//create router
const router = createRouter({
  history: createWebHistory(),
  routes, // <-- routes,
});

export default router;
