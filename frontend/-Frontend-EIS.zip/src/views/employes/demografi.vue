<template>
    <div class="my-container">

        <menubar />
        <h1>TES</h1>

        <pendidikanTerakhirChart />
        <pegawaiDepartemenChart />
        <pegawaiMasaKerjaChart />
        <statusPajakPTKPChart />
    </div>

</template>

<script>
import menubar from './menubar.vue';
// import employesController from '../../controller/employes-controller';
import pendidikanTerakhirChart from '../../components/pendidikanTerakhirChart.vue';
import pegawaiDepartemenChart from '../../components/pegawaiDepartemenChart.vue';
import pegawaiMasaKerjaChart from '../../components/pegawaiMasaKerjaChart.vue';
import statusPajakPTKPChart from '../../components/statusPajakPTKPChart.vue';


export default {
    // mixins: [employesController],
    components: {
        // employesController,
        menubar,
        pendidikanTerakhirChart,
        pegawaiDepartemenChart,
        pegawaiMasaKerjaChart,
        statusPajakPTKPChart

    },
}
</script>