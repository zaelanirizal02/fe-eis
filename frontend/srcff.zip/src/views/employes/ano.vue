<template>
    <div class="col">

        <masterChart />
    </div>
</template>

<script>
import masterChart from '../../components/masterChart.vue'
</script>