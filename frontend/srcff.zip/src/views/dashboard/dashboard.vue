<template>
    <masterChart />
</template>
<script>

import '../../assets/css/buttonStyle.css';
import '../employes/style.css';

import masterChart from '../../components/masterChart.vue'
export default {
    components: {
        masterChart,
    }
}
</script>