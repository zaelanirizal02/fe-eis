<template>
  <router-view></router-view>
</template>

<script>
// import '../src/assets/css/buttonStyle.css';
// import '../src/views/employes/style.css';

export default {
  name: 'App',

  data: () => ({
    //
  }),
}
</script>
