import { hrisServiceAuthInfo } from "../../api/index";

export default {
    data() {
        return {
            username: '',
            password: ''
        };
    },
    methods: {
        async login() {
            try {
                const response = await hrisServiceAuthInfo.post(
                    "/authInfo/auth/sign-in/login",
                    {
                        namaUser: this.username,
                        kataSandi: this.password
                    }
                );
                // Handle successful login
                console.log(response.data);
            } catch (error) {
                // Handle login error
                console.error('Login error:', error);
            }
        }
    }
}
