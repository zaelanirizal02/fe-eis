// Import komponen kalender untuk mendapatkan tglAkhir
import Calendar from "primevue/calendar";

export default {
  components: {
    Column,
    Dropdown,
    Calendar // Tambahkan komponen kalender
  },
  props: {
    // define any props here if needed
  },
  data() {
    return {
      representatives: [], // array untuk menyimpan data representatif
      responseDataPendidikanTerakhir: [],
      responseDataDepartemenTotal: [],
        selectedDate: null, // Menyimpan tglAkhir dari kalender
        date: null, // Menyimpan tanggal yang dipilih dari kalender
      minDate: null, // Atur minDate jika diperlukan
      maxDate: null, // Atur maxDate jika diperlukan
    };
  },
  mounted() {
    this.filterDataDashboard2();
    this.fetchDepartemenTotal(); // Panggil metode baru untuk mendapatkan data departemen total
    this.pendidikanTerakhir();
  },
  methods: {
    async filterDepartemenTotal(tglAkhir) { // Perbarui metode untuk menerima tglAkhir sebagai parameter
      try {
        const response = await hrisServiceHr1Mod1.get(
          `registrasiPegawai/findJumlahPegawaiFilterDepartemen?tglAkhir=${tglAkhir}`, // Gunakan tglAkhir dari parameter
          {
            headers: {
              "x-auth-token": `${token}`,
            },
          }
        );
        this.responseDataDepartemenTotal = response.data.data.listPegawai;
      } catch (error) {
        console.error("Error Fetching Data Jabatan Departemen", error);
      }
    },
    async fetchDepartemenTotal() { // Metode baru untuk memanggil filterDepartemenTotal dengan tglAkhir yang sesuai
      if (this.selectedDate) { // Pastikan selectedDate tidak null
        const formattedDate = this.formatDate(this.selectedDate); // Format tglAkhir jika diperlukan
        await this.filterDepartemenTotal(formattedDate); // Panggil filterDepartemenTotal dengan tglAkhir
      } else {
        console.error("Selected date is null"); // Log pesan kesalahan jika selectedDate null
      }
    },
     formatDate(date) {
    // Mendapatkan waktu dalam bentuk milidetik (epoch)
    return date.getTime();
  }
  }
};
