<template>
    <div class="justify-content-center custom-chart-bar">
        <div>
            <label for="periode">Pilih Periode</label>
            <select v-model="selectedPeriode" @change="filterData" id="periode">
                <option value="">Semua Periode</option>
                <option v-for="periode in periodeOptions" :value="periode">{{ periode }}</option>
            </select>
        </div>
        <Chart type="bar" :data="filteredChartData" :options="lightOptions" :plugins="plugins" />
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Chart from 'primevue/chart';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { hrisServiceHr1Mod1, token } from '../api/index';
import '../views/employes/style.css';

const plugins = [ChartDataLabels];
const chartData = ref({
    labels: [],
    datasets: [
        {
            data: [],
            backgroundColor: ['rgb(103, 101, 164)'],
            hoverBackgroundColor: ['rgb(64, 27, 27)'],
        },
    ],
});
const lightOptions = ref({
    plugins: {
        datalabels: {
            color: 'white',
            display: true, // Display data labels
            font: {
                weight: 'bold',
            },
        },
    },
});

const periodeOptions = ref([]);
const selectedPeriode = ref('');

onMounted(async () => {
    await fetchDataFromApi();
});

const fetchDataFromApi = async () => {
    try {
        const response = await hrisServiceHr1Mod1.get(
            'registrasiPegawai/findPajakPerBulan?noHistori=2402060004',
            {
                headers: {
                    'x-auth-token': `${token}`,
                },
            }
        );
        const data = response.data.data;

        // Jika data adalah objek, tambahkan nama periode ke options dan update chart data
        if (data && typeof data === 'object') {
            periodeOptions.value.push(data.namaPeriode);
            updateChartData(data);
        } else {
            console.error('Invalid data format');
        }
    } catch (error) {
        console.error('Error Fetching Pajak', error);
    }
};

const updateChartData = (data) => {
    const labels = data.namaPeriode;
    const seriesData = data.totalPajak;

    // Update chart data
    chartData.value.labels = labels;
    chartData.value.datasets[0].data = seriesData;
};

const filterData = () => {
    let filteredData = [];

    if (selectedPeriode.value === '') {
        // Show all data if no periode selected
        filteredData = chartData.value;
    } else {
        // Filter data based on selected periode
        const filteredLabels = chartData.value.labels.filter(label => label === selectedPeriode.value);
        const filteredSeriesData = chartData.value.datasets[0].data.filter((value, index) => chartData.value.labels[index] === selectedPeriode.value);

        filteredData = {
            labels: filteredLabels,
            datasets: [{
                ...chartData.value.datasets[0],
                data: filteredSeriesData
            }]
        };
    }

    filteredChartData.value = filteredData;
};

const filteredChartData = ref(chartData.value);
</script>
